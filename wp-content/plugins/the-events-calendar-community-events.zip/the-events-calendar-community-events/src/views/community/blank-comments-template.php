<?php
/**
 * Blank Comments Template
 * The only way to disable comment_template is to provide an empty file
 *
 * @package Tribe__Events__Community__Main
 * @since  1.0.3
 * @author Modern Tribe Inc.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
