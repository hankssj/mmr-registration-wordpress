<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Community__Templates' );


	class TribeCommunityEvents_Templates extends Tribe__Events__Community__Templates {

	}