<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Community__Schema' );


	class TribeCommunityEvents_Schema extends Tribe__Events__Community__Schema {

	}