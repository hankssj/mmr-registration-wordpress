<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Query' );


	class TribeEventsQuery extends Tribe__Events__Query {

	}