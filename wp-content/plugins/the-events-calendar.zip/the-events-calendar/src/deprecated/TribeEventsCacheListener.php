<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Cache_Listener' );


	class TribeEventsCacheListener extends Tribe__Events__Cache_Listener {

	}